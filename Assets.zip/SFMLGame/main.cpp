
#include <SFML/Graphics.hpp>

#include <iostream>
#include <stdlib.h>

using std::cout;
using std::endl;
using std::vector;
using sf::Texture;

#include "wall.h"
#include "player.h"
#include "Ghost.h"
#include "Bullet.h"
#include "Menu.h"

int main()
{
	sf::RenderWindow window(sf::VideoMode(1600, 900), "Ghost Hunters");
	bool isMenu = true;
	Menu menu(window.getSize().x, window.getSize().y);

	//Text for onScreen Score
	sf::Font fontArial;
	fontArial.loadFromFile("arial.ttf");
	sf::Text scoreText;
	scoreText.setFont(fontArial);
	scoreText.setString("Score: 0");
	scoreText.setColor(sf::Color::White);
	scoreText.setCharacterSize(30);
	scoreText.setPosition(1400, 10);

	//Text for onScreen Ammunition
	sf::Text ammunitionText;
	ammunitionText.setFont(fontArial);
	ammunitionText.setString("Ammunition: 0");
	ammunitionText.setColor(sf::Color::White);
	ammunitionText.setCharacterSize(30);
	ammunitionText.setPosition(20, 10);

	//menu
	if (isMenu)
	{
		while (isMenu && window.isOpen())
		{
			sf::Event event;

			while (window.pollEvent(event))
			{
				switch (event.type)
				{
				case sf::Event::KeyReleased:
					switch (event.key.code)
					{
					case sf::Keyboard::Up: //Or "W"
						menu.MoveUp();
						break;

					case sf::Keyboard::Down: //Or "S"
						menu.MoveDown();
						break;

					case sf::Keyboard::W: //Or "Up-Key"
						menu.MoveUp();
						break;

					case sf::Keyboard::S: //Or "Down-Key"
						menu.MoveDown();
						break;

					case sf::Keyboard::Return:
						switch (menu.getIndex())
						{
						case 0:
							std::cout << "Play button has been pressed" << std::endl;
							isMenu = false;
							break;
						case 1:
							//std::cout << "Option button has been pressed" << std::endl; //Not implemented
							break;
						case 2:
							window.close();
							break;
						}

						break;
					}

					break;
				case sf::Event::Closed:
					window.close();

					break;

				}

			}

			window.clear();

			menu.draw(window);

			window.display();
		}
	}

	srand((int)time(NULL));	
	 //Main Character
	Player player({ 40, 40 });
	player.setPos({ (float)window.getSize().x/2, (float)window.getSize().y/2 });



	Texture StartTexture;
	StartTexture.loadFromFile("GhostUp.png");

	//initialize the ghost army in random spots;
	Ghost G1[10]; // <-change number of enemies here
	for (int index = 0; index < 10; index++)
	{
		G1[index].setPosition((float)(rand() % (2*window.getSize().x + 50)), (float)(rand() % (2*window.getSize().y + 50)));
		G1[index].setTexture(StartTexture);
	}

	vector <Bullet> bulletsList;
	for (int i = 0; i < 5; i++) // Only five bulets per clip
	{
		Bullet newBullet(sf::Color::Blue, sf::Vector2f(0.3, 0.3), sf::Vector2f(-100, -100));
		//newBullet.setTexture(FireBallFacedUp);
		bulletsList.push_back(newBullet);
	}


	bool isRight = false;
	bool isLeft = false;
	bool isUp = false;
	bool isDown = false;
	bool spaceKeyPress = false;
	bool reloadKeyPress = false; //"R"

	bool wRightCollide = false;
	bool wLeftCollide = false;
	bool wUpCollide = false;
	bool wDownCollide = false;
	bool eRightCollide = false;
	bool eLeftCollide = false;
	bool eUpCollide = false;
	bool eDownCollide = false;
	bool nRightCollide = false;
	bool nLeftCollide = false;
	bool nUpCollide = false;
	bool nDownCollide = false;
	bool sRightCollide = false;
	bool sLeftCollide = false;
	bool sUpCollide = false;
	bool sDownCollide = false;

	string Direction = "up";
	int ammunition = 5;
	int score = 0;

	Wall WestWall(*(new sf::Vector2f(window.getSize().x / 4, (window.getSize().y / 2) - 200)));
	Wall EastWall(*(new sf::Vector2f((window.getSize().x / 4)*3, (window.getSize().y / 2) - 200)));
	Wall NorthWall(*(new sf::Vector2f((window.getSize().x / 2)-175 , (window.getSize().y / 4) -25)));
	NorthWall.setNewSize({400, 40}); // set the wall to lay horizontally
	Wall SouthWall(*(new sf::Vector2f((window.getSize().x / 2)-175 , (window.getSize().y / 4)*3 -10)));
	SouthWall.setNewSize({400, 40});


	//Menu menu(window.getSize().x, window.getSize().y);

	while (window.isOpen())
	{
		sf::Event event;

		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();

			if (event.type == sf::Event::KeyPressed)
			{
				if (!isRight && event.key.code == sf::Keyboard::D)
				{
					isRight = true;
					Direction = "right";
				}
				if (!isUp && event.key.code == sf::Keyboard::W)
				{
					isUp = true;
					Direction = "up";
				}
				if (!isLeft && event.key.code == sf::Keyboard::A)
				{
					isLeft = true;
					Direction = "left";
				}
				if (!isDown && event.key.code == sf::Keyboard::S)
				{
					isDown = true;
					Direction = "down";
				}
				if (!spaceKeyPress && event.key.code == sf::Keyboard::Space) // Shoot Bullets
				{
					spaceKeyPress = true;
				}
				if (!reloadKeyPress && event.key.code == sf::Keyboard::R)
				{
					reloadKeyPress = true;
				}
			}
			if (event.type == sf::Event::KeyReleased)
			{
				if (isRight && event.key.code == sf::Keyboard::D)
				{
					isRight = false;
					cout << "D Key Pressed" << endl; // To track whats happening in console
					//Direction = "right";
				}
				if (isUp && event.key.code == sf::Keyboard::W)
				{
					isUp = false;
					cout << "W Key Pressed" << endl;
					//Direction = "up";
				}
				if (isLeft && event.key.code == sf::Keyboard::A)
				{
					isLeft = false;
					cout << "A Key Pressed" << endl;
					//Direction = "left";
				}
				if (isDown && event.key.code == sf::Keyboard::S)
				{
					isDown = false;
					cout << "S Key Pressed" << endl;
					//Direction = "down";
				}
				if (spaceKeyPress && event.key.code == sf::Keyboard::Space) // Shoot Bullets
				{
					spaceKeyPress = false;
					cout << "Space Key Pressed" << endl;
				}
			}
		}

				// boundary detections
				if (player.getXPos() + player.getXsize() >= window.getSize().x)
				{
					isRight = false;
				}
				if (player.getXPos() <= 0)
				{
					isLeft = false;
				}
				if (player.getYPos() <= 0)
				{
					isUp = false;
				}
				if (player.getYPos() + player.getYsize() >= window.getSize().y)
				{
					isDown = false;
				}


				//wall collision
				// if the position of the player is the same as the position of a side of any of the wall
				// then the collider boolean is set to true and the player cant move that direction anymore while still in contact

				//WESTERN WALL
				if ((player.getXPos() <= WestWall.getPosition().x + WestWall.getSize().x + 2 && player.getXPos() > WestWall.getPosition().x) && (player.getYPos() + player.getYsize() > WestWall.getPosition().y) && player.getYPos() < WestWall.getPosition().y + WestWall.getSize().y) // right face
				{
					wLeftCollide = true;
				}
				else
				{
					wLeftCollide = false;
				}
				if ((player.getXPos() + player.getXsize() >= WestWall.getPosition().x - 2 && player.getXPos() + player.getXsize() < WestWall.getPosition().x + WestWall.getSize().x) && (player.getYPos() + player.getYsize() > WestWall.getPosition().y) && player.getYPos() < WestWall.getPosition().y + WestWall.getSize().y) // left face
				{
					wRightCollide = true;
				}
				else
				{
					wRightCollide = false;
				}
				if ((player.getYPos() + player.getYsize() >= WestWall.getPosition().y - 2 && player.getYPos() + player.getYsize() < WestWall.getPosition().y + WestWall.getSize().y) && (player.getXPos() + player.getXsize() > WestWall.getPosition().x) && (player.getXPos() < WestWall.getPosition().x + WestWall.getSize().x)) // top face
				{
					wDownCollide = true;
				}
				else
				{
					wDownCollide = false;
				}
				if ((player.getYPos() <= WestWall.getPosition().y + WestWall.getSize().y + 2 && player.getYPos() > WestWall.getPosition().y) && (player.getXPos() + player.getXsize() > WestWall.getPosition().x) && (player.getXPos() < WestWall.getPosition().x + WestWall.getSize().x)) // bottom face
				{
					wUpCollide = true;
				}
				else
				{
					wUpCollide = false;
				}

				//EASTERN WALL
				if ((player.getXPos() <= EastWall.getPosition().x + EastWall.getSize().x + 2 && player.getXPos() > EastWall.getPosition().x) && (player.getYPos() + player.getYsize() > EastWall.getPosition().y) && player.getYPos() < EastWall.getPosition().y + EastWall.getSize().y) // right face
				{
					eLeftCollide = true;
				}
				else
				{
					eLeftCollide = false;
				}
				if ((player.getXPos() + player.getXsize() >= EastWall.getPosition().x - 2 && player.getXPos() + player.getXsize() < EastWall.getPosition().x + EastWall.getSize().x) && (player.getYPos() + player.getYsize() > EastWall.getPosition().y) && player.getYPos() < EastWall.getPosition().y + EastWall.getSize().y) // left face
				{
					eRightCollide = true;
				}
				else
				{
					eRightCollide = false;
				}
				if ((player.getYPos() + player.getYsize() >= EastWall.getPosition().y - 2 && player.getYPos() + player.getYsize() < EastWall.getPosition().y + EastWall.getSize().y) && (player.getXPos() + player.getXsize() > EastWall.getPosition().x) && (player.getXPos() < EastWall.getPosition().x + EastWall.getSize().x)) // top face
				{
					eDownCollide = true;
				}
				else
				{
					eDownCollide = false;
				}
				if ((player.getYPos() <= EastWall.getPosition().y + EastWall.getSize().y + 2 && player.getYPos() > EastWall.getPosition().y) && (player.getXPos() + player.getXsize() > EastWall.getPosition().x) && (player.getXPos() < EastWall.getPosition().x + EastWall.getSize().x)) // bottom face
				{
					eUpCollide = true;
				}
				else
				{
					eUpCollide = false;
				}

				//NORTHERN WALL
				if ((player.getXPos() <= NorthWall.getPosition().x + NorthWall.getSize().x + 2 && player.getXPos() > NorthWall.getPosition().x) && (player.getYPos() + player.getYsize() > NorthWall.getPosition().y) && player.getYPos() < NorthWall.getPosition().y + NorthWall.getSize().y) // right face
				{
					nLeftCollide = true;
				}
				else
				{
					nLeftCollide = false;
				}
				if ((player.getXPos() + player.getXsize() >= NorthWall.getPosition().x - 2 && player.getXPos() + player.getXsize() < NorthWall.getPosition().x + NorthWall.getSize().x) && (player.getYPos() + player.getYsize() > NorthWall.getPosition().y) && player.getYPos() < NorthWall.getPosition().y + NorthWall.getSize().y) // left face
				{
					nRightCollide = true;
				}
				else
				{
					nRightCollide = false;
				}
				if ((player.getYPos() + player.getYsize() >= NorthWall.getPosition().y - 2 && player.getYPos() + player.getYsize() < NorthWall.getPosition().y + NorthWall.getSize().y) && (player.getXPos() + player.getXsize() > NorthWall.getPosition().x) && (player.getXPos() < NorthWall.getPosition().x + NorthWall.getSize().x)) // top face
				{
					nDownCollide = true;
				}
				else
				{
					nDownCollide = false;
				}
				if ((player.getYPos() <= NorthWall.getPosition().y + NorthWall.getSize().y + 2 && player.getYPos() > NorthWall.getPosition().y) && (player.getXPos() + player.getXsize() > NorthWall.getPosition().x) && (player.getXPos() < NorthWall.getPosition().x + NorthWall.getSize().x)) // bottom face
				{
					nUpCollide = true;
				}
				else
				{
					nUpCollide = false;
				}

				//SOUTHERN WALL
				if ((player.getXPos() <= SouthWall.getPosition().x + SouthWall.getSize().x + 2 && player.getXPos() > SouthWall.getPosition().x) && (player.getYPos() + player.getYsize() > SouthWall.getPosition().y) && player.getYPos() < SouthWall.getPosition().y + SouthWall.getSize().y) // right face
				{
					sLeftCollide = true;
				}
				else
				{
					sLeftCollide = false;
				}
				if ((player.getXPos() + player.getXsize() >= SouthWall.getPosition().x - 2 && player.getXPos() + player.getXsize() < SouthWall.getPosition().x + SouthWall.getSize().x) && (player.getYPos() + player.getYsize() > SouthWall.getPosition().y) && player.getYPos() < SouthWall.getPosition().y + SouthWall.getSize().y) // left face
				{
					sRightCollide = true;
				}
				else
				{
					sRightCollide = false;
				}
				if ((player.getYPos() + player.getYsize() >= SouthWall.getPosition().y - 2 && player.getYPos() + player.getYsize() < SouthWall.getPosition().y + SouthWall.getSize().y) && (player.getXPos() + player.getXsize() > SouthWall.getPosition().x) && (player.getXPos() < SouthWall.getPosition().x + SouthWall.getSize().x)) // top face
				{
					sDownCollide = true;
				}
				else
				{
					sDownCollide = false;
				}
				if ((player.getYPos() <= SouthWall.getPosition().y + SouthWall.getSize().y + 2 && player.getYPos() > SouthWall.getPosition().y) && (player.getXPos() + player.getXsize() > SouthWall.getPosition().x) && (player.getXPos() < SouthWall.getPosition().x + SouthWall.getSize().x)) // bottom face
				{
					sUpCollide = true;
				}
				else
				{
					sUpCollide = false;
				}




				//player movement
				if (isRight == true && (nRightCollide != true && eRightCollide != true && sRightCollide != true && wRightCollide != true))
				{
					player.move({ (float)0.3, 0 });
				}
				if (isLeft == true && (nLeftCollide != true && eLeftCollide != true && sLeftCollide != true && wLeftCollide != true))
				{
					player.move({ (float)-0.3, 0 });
				}
				if (isUp == true && (nUpCollide != true && eUpCollide != true && sUpCollide != true && wUpCollide != true))
				{
					player.move({ 0, (float)-0.3 });
				}
				if (isDown == true && (nDownCollide != true && eDownCollide != true && sDownCollide != true && wDownCollide != true))
				{
					player.move({ 0, (float)0.3 });
				}


				//Bullet logic
				if (ammunition > 0 && spaceKeyPress == true) // Shoot Bullets
				{
					bulletsList[ammunition - 1].setISInMotion(true);
					bulletsList[ammunition - 1].setPosition(player.getXPos(), player.getYPos());
					bulletsList[ammunition - 1].setDirection(Direction);
					ammunition--;

					spaceKeyPress = false;
				}


				if (bulletsList[0].getISInMotion() == true) //Faster runtime than using a loop
				{
					bulletsList[0].fire();
					if (!(bulletsList[0].getPosition().x >= 0 && bulletsList[0].getPosition().x <= window.getSize().x && bulletsList[0].getPosition().y >= 0 && bulletsList[0].getPosition().y <= window.getSize().y))
					{
						bulletsList[0].setISInMotion(false);
						bulletsList[0].setPosition(-100, -100);
					}
				}
				if (bulletsList[1].getISInMotion() == true)
				{
					bulletsList[1].fire();
					if (!(bulletsList[1].getPosition().x >= 0 && bulletsList[1].getPosition().x <= window.getSize().x  && bulletsList[1].getPosition().y >= 0 && bulletsList[1].getPosition().y <= window.getSize().y))
					{
						bulletsList[1].setISInMotion(false);
						bulletsList[1].setPosition(-100, -100);
					}
				}
				if (bulletsList[2].getISInMotion() == true)
				{
					bulletsList[2].fire();
					if (!(bulletsList[2].getPosition().x >= 0 && bulletsList[2].getPosition().x <= window.getSize().x && bulletsList[2].getPosition().y >= 0 && bulletsList[2].getPosition().y <= window.getSize().y))
					{
						bulletsList[2].setISInMotion(false);
						bulletsList[2].setPosition(-100, -100);
					}
				}
				if (bulletsList[3].getISInMotion() == true)
				{
					bulletsList[3].fire();
					if (!(bulletsList[3].getPosition().x >= 0 && bulletsList[3].getPosition().x <= window.getSize().x && bulletsList[3].getPosition().y >= 0 && bulletsList[3].getPosition().y <= window.getSize().y))
					{
						bulletsList[3].setISInMotion(false);
						bulletsList[3].setPosition(-100, -100);
					}
				}
				if (bulletsList[4].getISInMotion() == true)
				{
					bulletsList[4].fire();
					if (!(bulletsList[4].getPosition().x >= 0 && bulletsList[4].getPosition().x <= window.getSize().x  && bulletsList[4].getPosition().y >= 0 && bulletsList[4].getPosition().y <= window.getSize().y))
					{
						bulletsList[4].setISInMotion(false);
						bulletsList[4].setPosition(-100, -100);
					}
				}
				if (bulletsList[5].getISInMotion() == true)
				{
					bulletsList[5].fire();
					if (!(bulletsList[5].getPosition().x >= 0 && bulletsList[5].getPosition().x <= window.getSize().x  && bulletsList[5].getPosition().y >= 0 && bulletsList[5].getPosition().y <= window.getSize().y))
					{
						bulletsList[5].setISInMotion(false);
						bulletsList[5].setPosition(-100, -100);
					}
				}
				//Reload Clip

				if (reloadKeyPress) //"R"
				{
					ammunition = 5;
					reloadKeyPress = false;
					spaceKeyPress = false;
				}

				//Ghost hit by bullet
				for (int i = 0; i < 10; i++)
				{
					G1[i].hitByBullet(bulletsList[0], score);
					G1[i].hitByBullet(bulletsList[1], score);
					G1[i].hitByBullet(bulletsList[2], score);
					G1[i].hitByBullet(bulletsList[3], score);
					G1[i].hitByBullet(bulletsList[4], score);
				}

				//If Player is hit by ghost
				for (int i = 0; i < 10; i++)
				{
					if (G1[i].touchPlayer(player))
					{
						cout << "Hit by Ghost!" << endl;
						cout << player.getHealth() << endl;
						player.setHealth(0);

					}
				}

				// If Bullet hits a Wall // Collision Logic
				for (int i = 0; i < 5; i++)
				{
					bulletsList[i].collideWithWall(NorthWall.getPosition().x, NorthWall.getPosition().y, NorthWall.getSize().x, NorthWall.getSize().y);
					bulletsList[i].collideWithWall(SouthWall.getPosition().x, SouthWall.getPosition().y, SouthWall.getSize().x, SouthWall.getSize().y);
					bulletsList[i].collideWithWall(WestWall.getPosition().x, WestWall.getPosition().y, WestWall.getSize().x, WestWall.getSize().y);
					bulletsList[i].collideWithWall(EastWall.getPosition().x, EastWall.getPosition().y, EastWall.getSize().x, EastWall.getSize().y);
				}


				//Draw objects
				window.clear();
				
				player.draw(window);
				window.draw(WestWall);
				window.draw(EastWall);
				window.draw(NorthWall);
				window.draw(SouthWall);
				window.draw(scoreText);
				window.draw(ammunitionText);

				for (int i = 0; i < bulletsList.size(); i++)
				{
					window.draw(bulletsList[i]);
				}

				for (int index = 0; index < 10; index++) //If number of ghosts is changed. This must be changed
				{
					G1[index].attack(player);
					window.draw(G1[index]);
				}
				//End game if player is out of health
				if (player.getHealth() <= 0)
				{
					cout << "you DIED!!!!" << endl;
					window.close();
				}

				//Keep Track of Score
				scoreText.setString("Score: " + std::to_string(score));


				//Keep Track of Ammunition
				ammunitionText.setString("Ammunition: " + std::to_string(ammunition));
				
				//cout << player.getXPos() << endl;
				//cout << player.getYPos() << endl;

				window.display();			
		}
		
	return 0;
}