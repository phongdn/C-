#include "Bullet.h"
Bullet::Bullet(sf::Color const &newColor, sf::Vector2f const &size, sf::Vector2f const &pos)
{
	//this->setFillColor(newColor);
	this->setScale(size);
	this->size = size;
	//this->setSize(size);
	this->setPosition(pos);
	if (!FireBallFacedDown.loadFromFile("BulletDown.png") || FireBallFacedUp.loadFromFile("BulletUp.png") || FireBallFacedLeft.loadFromFile("BulletLeft.png") || FireBallFacedRight.loadFromFile("BulletRight.png"))
	{
		cout << "Problem loading a Bullet Texture" << endl;
	}
	FireBallFacedDown.loadFromFile("BulletDown.png"); //Some issues with loading image
	FireBallFacedUp.loadFromFile("BulletUp.png");
	FireBallFacedLeft.loadFromFile("BulletLeft.png");
	FireBallFacedRight.loadFromFile("BulletRight.png");

	FireBallFacedDown.setSmooth(true);
	FireBallFacedUp.setSmooth(true);
	FireBallFacedLeft.setSmooth(true);
	FireBallFacedRight.setSmooth(true);
}

Bullet::~Bullet()
{
	//delete this;
}

void Bullet::setDirection(string dir)
{
	this->Direction = dir;
}

void Bullet::fire()
{
	if (this->Direction == "left")
	{
		this->setTexture(FireBallFacedLeft);
		this->move(-3, 0);
	}
	if (this->Direction == "right")
	{
		this->setTexture(FireBallFacedRight);
		this->move(3, 0);
	}
	if (this->Direction == "up")
	{
		this->setTexture(FireBallFacedUp);
		this->move(0, -3);
	}
	if (this->Direction == "down")
	{
		this->setTexture(FireBallFacedDown);
		this->move(0, 3);
	}
}

float Bullet::getRightSide()
{
	return this->getPosition().x + this->getScale().x;
}
float Bullet::getLeftSide()
{
	return this->getPosition().x;
}
float Bullet::getTopSide()
{
	return this->getPosition().y;
}
float Bullet::getBottomSide()
{
	return this->getPosition().y + this->getScale().y;
}

void Bullet::setISInMotion(bool status)
{
	this->IsInMotion = status;
}

bool Bullet::getISInMotion()
{
	return this->IsInMotion;
}

void Bullet::collideWithWall(float xPos, float yPos, float xSize, float ySize) //Detects collision with walls
{
	if ((xPos + xSize) > this->getLeftSide() && yPos < this->getBottomSide()
		&& (yPos + ySize) > this->getTopSide() && xPos < this->getLeftSide() + 10)
	{
		this->setPosition(-100, -100);
	}
}