#pragma once
#include <iostream>
#include "player.h"
#include <SFML/Graphics.hpp>

using std::string;
using sf::Vector2f;
using sf::RenderWindow;
using sf::RectangleShape;
using sf::Texture;
using std::cout;
using std::endl;

class Bullet : public sf::Sprite
{

public:
	Bullet(sf::Color const &newColor, sf::Vector2f const &size, sf::Vector2f const &pos);
	~Bullet();
	void fire();

	void setDirection(string dir);
	void setISInMotion(bool status);

	bool getISInMotion();

	float getRightSide();
	float getLeftSide();
	float getTopSide();
	float getBottomSide();

	void collideWithWall(float xPos, float yPos, float xSize, float ySize);

private:
	Vector2f size;
	bool IsInMotion;
	string Direction;
	Texture FireBallFacedDown;
	Texture FireBallFacedUp;
	Texture FireBallFacedLeft;
	Texture FireBallFacedRight;
};