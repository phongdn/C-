#pragma once

#include <SFML/Graphics.hpp>

class Player
{
public:
	Player(sf::Vector2f size)
	{
		player.setSize(size);
		player.setFillColor(sf::Color::Blue);
		health = 100;
	}

	~Player()
	{

	}

	void draw(sf::RenderWindow &window)
	{
		window.draw(player);
	}

	void move(sf::Vector2f distance)
	{
		player.move(distance);
	}

	void setPos(sf::Vector2f newPos)
	{
		player.setPosition(newPos);
	}
	float getXPos()
	{
		return player.getPosition().x;
	}
	float getYPos()
	{
		return player.getPosition().y;
	}
	float getXsize()
	{
		return player.getSize().x;
	}
	float getYsize()
	{
		return player.getSize().y;
	}
	void setHealth(const int newHealth)
	{
		this->health = newHealth;
	}
	int getHealth() const
	{
		return health;
	}

	//Used for detecting if ghost touches player
	float getRightSide()
	{
		return player.getPosition().x + player.getSize().x;
	}
	float getLeftSide()
	{
		return player.getPosition().x;
	}
	float getTopSide()
	{
		return player.getPosition().y;
	}
	float getBottomSide()
	{
		return player.getPosition().y + player.getSize().y;
	}
private:
	sf::RectangleShape player;
	int health;
};