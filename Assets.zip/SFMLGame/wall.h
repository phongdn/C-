#pragma once

#include <SFML/Graphics.hpp>


class Wall : public sf::RectangleShape
{
public:
	Wall(sf::Vector2f &position)
	{
		this->setSize({ 40, 400 }); // all default walls will lay verticle
		this->setFillColor(sf::Color::Black);
		this->setOutlineThickness(2);
		this->setOutlineColor(sf::Color::White);
		this->setPosition(position);
	}

	void setNewSize(sf::Vector2f newSize)
	{
		this->setSize(newSize);
	}

	const float getXsize()
	{
		return this->getSize().x;
	}
	const float getYsize()
	{
		return this->getSize().y;
	}

private:

};