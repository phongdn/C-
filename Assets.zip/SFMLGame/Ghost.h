#pragma once

#include "player.h"
#include "Bullet.h"
#include <SFML/Graphics.hpp>

class Ghost : public sf::Sprite
{
public:
	Ghost()
	{
		this->setScale( 2, 2 );
		//this->setFillColor(sf::Color::White);
		//health = 100;
		power = 100;
		//Direction = "up";
		GhostFacingUp.loadFromFile("GhostUp.png");
		GhostFacingDown.loadFromFile("GhostDown.png");;
		GhostFacingLeft.loadFromFile("GhostLeft.png");;
		GhostFacingRight.loadFromFile("GhostRight.png");;
	}
	void attack(Player &player)
	{
		this->follow(player);

		if (this->getPosition().x == player.getXPos() && this->getPosition().y == player.getYPos())
		{
			player.setHealth(player.getHealth() - power);
			cout << player.getHealth() << endl;
		}
	}
	void follow(Player &player)
	{
		if (player.getXPos() > this->getPosition().x)
		{
			this->setTexture(GhostFacingRight);
			this->move({ (float).1, 0 }); // move right
		}
		if (player.getXPos() < this->getPosition().x)
		{
			this->setTexture(GhostFacingLeft);
			this->move({ (float)-.1, 0 }); // move left
		}
		if (player.getYPos() > this->getPosition().y)
		{
			this->setTexture(GhostFacingDown);
			this->move({ 0,(float).1 }); // move down
		}
		if (player.getYPos() < this->getPosition().y)
		{
			this->setTexture(GhostFacingUp);
			this->move({ 0, (float)-.1 }); // move up
		}
	}

	void hitByBullet(Bullet & b, int & score)
	{
		if (b.getRightSide() > this->getPosition().x && b.getTopSide() < this->getPosition().y + this->getScale().y + 60
			&& b.getBottomSide() > this->getPosition().y && b.getLeftSide() < this->getPosition().x + 50)
		{
			this->setPosition((float)(rand() % 2000 + 805), (float)(rand() % 2000 + 805));
			b.setPosition(-500, -500);
			score += 10;
			cout << score << endl;
		}
	}

	bool touchPlayer(Player & p)
	{
		if (p.getRightSide() > this->getPosition().x  && p.getTopSide() < this->getPosition().y + this->getScale().y + 90
			&& p.getBottomSide() > this->getPosition().y && p.getLeftSide() < this->getPosition().x + 42)
		{
			return true;
		}
		return false;
	}
	
	
private:
	//int health;
	int power;
	//string Direction;
	Texture GhostFacingUp;
	Texture GhostFacingDown;
	Texture GhostFacingLeft;
	Texture GhostFacingRight;
};