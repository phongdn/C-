Names: Phong Nguyen, Joseph Cunningham, Alex Wilsey
Note: This was created and compiled using Visual Studio 2017. You might need to change the Windows SDK Version in the settings for it to compile

Team Name: Retro

Class: CPTS 122

Description: Enemies are ghosts and you're a hunter aimed to kill as many as possible.
You earn 10 points per ghost killed and there will be an infinite wave of ghosts.
There can only be 10 ghosts on the screen at a time, unless overwise changed in the code.
You play until you are killed by a ghost.

Controls:   "W" = Move Player Up
			"S" = Move Player Down
			"A" = Move Player Left
			"D" = Move Player Right
			"R" = Reload Clip (You only have 5 bullets per clip)
			"Space" = Shoot Gun


Textures Acquired From:
https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&cad=rja&uact=8&ved=0ahUKEwia4rzPlMPTAhUW0WMKHQt5DEgQjRwIBw&url=http%3A%2F%2Ffinalfantasy.wikia.com%2Fwiki%2FFile%3AFF6_iOS_Ghost_Sprites.png&psig=AFQjCNHOhmR34ZFLgDsnrAgjGsQJwkNSCw&ust=1493331494388079
https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&cad=rja&uact=8&ved=0ahUKEwj8n7bpv8PTAhUI2IMKHUVMAswQjRwIBw&url=https%3A%2F%2Fchrismalnu.wordpress.com%2Fcategory%2Fshoot-em-up%2F&psig=AFQjCNHZTQMa6rD5kcrcdtWoO8SPJnJmeQ&ust=1493343400433314
https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&cad=rja&uact=8&ved=0ahUKEwj6vNPMyMPTAhVClVQKHSTSDmoQjRwIBw&url=http%3A%2F%2Fmillionthvector.blogspot.com%2Fp%2Ffree-sprites.html&psig=AFQjCNFdr5i31KFGSronbyUpx-GCILsPtQ&ust=1493345674739015
